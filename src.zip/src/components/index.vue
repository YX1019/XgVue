<template>
  <div class="index">
     <topMenu></topMenu>
  </div>
</template>

<script>
// import axios from "axios";
// import topMenu from "@/topMenu/topMenu";
export default {
  name: 'index',
  data () {
    return {
    }
  }
//  ,
//  components: {
//    topMenu
//  }
}
</script>

<style >

</style>
