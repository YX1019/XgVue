import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import index from '@/components/index'
import topMenu from '@/components/topMenu/topMenu'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/topMenu/topMenu',
      name: 'topMenu',
      component: topMenu
    },
    {
      path: '/index',
      name: 'index',
      component: index
    }
  ]
})
